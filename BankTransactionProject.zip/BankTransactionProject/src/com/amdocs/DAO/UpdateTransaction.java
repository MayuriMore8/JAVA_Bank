package com.amdocs.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateTransaction 
{
	
	// SQL queries
		private static final String UPDATE_TRANSACTION = "UPDATE transactions SET NewBal=?, TransStat=? WHERE TransID=?";
		
	
	// Update transaction details in the database
		public static void updateTransaction(Connection con, double newBal, String validity, int transID)
				throws SQLException 
		{
			
			// Prepare and execute the update statement
			PreparedStatement update = con.prepareStatement(UPDATE_TRANSACTION);

			update.setDouble(1, newBal);
			update.setString(2, validity);
			update.setInt(3, transID);

			update.executeUpdate();

		}


}
