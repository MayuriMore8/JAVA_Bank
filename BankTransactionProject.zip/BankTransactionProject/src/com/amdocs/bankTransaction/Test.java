package com.amdocs.bankTransaction;

import com.amdocs.DAO.ConnectionProvider;
import com.amdocs.DAO.DisplayAllTransactions;
import com.amdocs.DAO.FetchTransactions;

public class Test {

	
	public static void main(String[] args) 
	{

		try {
			// Process transactions and print success message
			FetchTransactions.processTransactions();
			System.out.println("Transaction Fetch   Successfully !!");
			
			System.out.println();
			
			DisplayAllTransactions.displayAllRecords();
			
			// Close the database connection
			ConnectionProvider.closeConnection();
		} 
		catch (Exception e) 
		{
			// Print the stack trace in case of an exception
			e.printStackTrace();
		} 

	}
}

